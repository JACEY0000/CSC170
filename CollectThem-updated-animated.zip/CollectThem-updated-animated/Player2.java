import greenfoot.*;

public class Player2 extends Actor {
    private int scoreP2 = 0;
    private GreenfootImage originalImage;
    private GreenfootImage collectingImage; 
    private GreenfootImage[] playerWalkAnimationP2; 
    private boolean isMovingP2 = false; 
    private int animationFrameP2 = 0;
    private int animationTimerP2 = 0;
    
    
    private boolean isCollecting = false;
    private int collectionTimer = 0;
    private final int COLLECTION_DURATION = 10; 

    public Player2() {
        originalImage = getImage();
        
        collectingImage = new GreenfootImage("player_pickup_1.png");
        collectingImage.scale(80, 80); 
        
        playerWalkAnimationP2 = new GreenfootImage[4]; 

       
        playerWalkAnimationP2[0] = new GreenfootImage("p2_walk1.png"); 
        playerWalkAnimationP2[1] = new GreenfootImage("p2_walk2.png");
        playerWalkAnimationP2[2] = new GreenfootImage("p2_walk3.png");
        playerWalkAnimationP2[3] = new GreenfootImage("p2_walk4.png");
        

        
        for (int i = 0; i < playerWalkAnimationP2.length; i++) {
            playerWalkAnimationP2[i].scale(originalImage.getWidth(), originalImage.getHeight());
        }
    }
    
    public void act() {
        
        isMovingP2 = false; 

        checkKeysP2();
        checkCollisionP2();
        showScoreP2();
        handleAnimationsP2(); 
    }

    public void checkKeysP2() {
        if (Greenfoot.isKeyDown("a")) {
            move(-3);
            isMovingP2 = true;
        }
        if (Greenfoot.isKeyDown("d")) {
            move(3);
            isMovingP2 = true;
        }
        if (Greenfoot.isKeyDown("w")) {
            setLocation(getX(), getY() - 3);
            isMovingP2 = true;
        }
        if (Greenfoot.isKeyDown("s")) {
            setLocation(getX(), getY() + 3);
            isMovingP2 = true;
        }
    }
    
    private void handleAnimationsP2() {
        if (isCollecting) {
            animateCollectionP2(); 
        } else if (isMovingP2) {
            animateMovementP2(); 
        } else {
            
            setImage(originalImage);
            animationFrameP2 = 0;
            animationTimerP2 = 0;
        }
    }

    /**
     * Checks if the second player has collided with gold, plays a sound, and starts the animation.
     */
    public void checkCollisionP2() {
        Actor gold = getOneIntersectingObject(Gold.class);
        if (gold != null) {
            getWorld().removeObject(gold);
            Greenfoot.playSound("cha_ching-sound_effect_download.wav");
            scoreP2++;

            
            isCollecting = true;
            collectionTimer = COLLECTION_DURATION;
            setImage(collectingImage);
        }
    }

    
    private void animateMovementP2() {
        animationTimerP2++;
        
        if (animationTimerP2 % 4 == 0) {
            setImage(playerWalkAnimationP2[animationFrameP2]);
            
            animationFrameP2 = (animationFrameP2 + 1) % playerWalkAnimationP2.length;
        }
    }
    
    private void animateCollectionP2() {
        collectionTimer--;
        if (collectionTimer <= 0) {
            isCollecting = false;
            
        }
    }

    public void showScoreP2() {
        getWorld().showText("P2 Score: " + scoreP2, 550, 25);
    }
}