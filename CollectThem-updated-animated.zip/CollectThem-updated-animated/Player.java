import greenfoot.*;

public class Player extends Actor {
    private int score = 0;
    private GreenfootImage[] playerPickupAnimation;
    private GreenfootImage[] playerWalkAnimation; 
    private int animationFrame = 0; 
    private int animationTimer = 0; 
    private boolean isAnimating = false;
    private boolean isMoving = false;  
    private GreenfootImage defaultImage; 

    public Player() {
        defaultImage = getImage(); 
        
        
        playerPickupAnimation = new GreenfootImage[3]; 
        playerPickupAnimation[0] = new GreenfootImage("player_pickup_4.png");
        playerPickupAnimation[1] = new GreenfootImage("player_pickup_5.png");
        playerPickupAnimation[2] = new GreenfootImage("player_pickup_6.png");
        
        for (int i = 0; i < playerPickupAnimation.length; i++) {
            playerPickupAnimation[i].scale(40, 40); 
        }

        
        playerWalkAnimation = new GreenfootImage[4]; 
        playerWalkAnimation[0] = new GreenfootImage("player_walk1.png");
        playerWalkAnimation[1] = new GreenfootImage("player_walk2.png");
        playerWalkAnimation[2] = new GreenfootImage("player_walk3.png");
        playerWalkAnimation[3] = new GreenfootImage("player_walk4.png");

        
         for (int i = 0; i < playerWalkAnimation.length; i++) {
            playerWalkAnimation[i].scale(120, 120); 
        }
    }
  
    public void act() {
        
        isMoving = false; 

        checkKeys();
        checkCollision();
        showScore();

        
        if (isAnimating) {
            animatePickup();
        } else if (isMoving) {
            animateMovement(); 
        } else {
            
            setImage(defaultImage);
            animationFrame = 0;
            animationTimer = 0;
        }
    }

    public void checkKeys() {
        if (Greenfoot.isKeyDown("left")) {
            move(-3);
            isMoving = true; 
        }
        if (Greenfoot.isKeyDown("right")) {
            move(3);
            isMoving = true; 
        }
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 3);
            isMoving = true; 
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 3);
            isMoving = true; 
        }
    }

    public void checkCollision() {
        Actor gold = getOneIntersectingObject(Gold.class);
        if (gold != null) {
            getWorld().removeObject(gold);
            Greenfoot.playSound("cha_ching-sound_effect_download.wav");
            score++;
            startPickupAnimation(); 
        }
    }

    public void showScore() {
        getWorld().showText("P1 Score: " + score, 50, 25);
    }

    private void startPickupAnimation() {
        isAnimating = true;
        animationFrame = 0;
        animationTimer = 0;
    }

    private void animatePickup() {
        animationTimer++;
        if (animationTimer % 5 == 0) { 
            setImage(playerPickupAnimation[animationFrame]);
            animationFrame++;
            if (animationFrame >= playerPickupAnimation.length) {
                isAnimating = false; 
                
            }
        }
    }

    
    private void animateMovement() {
        animationTimer++;
        
        if (animationTimer % 4 == 0) {
            
            setImage(playerWalkAnimation[animationFrame]);
            animationFrame = (animationFrame + 1) % playerWalkAnimation.length;
        }
    }
}